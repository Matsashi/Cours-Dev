<?php
/**
 * La configuration de base de votre installation WordPress.
 *
 * Ce fichier est utilisé par le script de création de wp-config.php pendant
 * le processus d’installation. Vous n’avez pas à utiliser le site web, vous
 * pouvez simplement renommer ce fichier en « wp-config.php » et remplir les
 * valeurs.
 *
 * Ce fichier contient les réglages de configuration suivants :
 *
 * Réglages MySQL
 * Préfixe de table
 * Clés secrètes
 * Langue utilisée
 * ABSPATH
 *
 * @link https://fr.wordpress.org/support/article/editing-wp-config-php/.
 *
 * @package WordPress
 */

// ** Réglages MySQL - Votre hébergeur doit vous fournir ces informations. ** //
/** Nom de la base de données de WordPress. */
define( 'DB_NAME', 'wineetvin' );

/** Utilisateur de la base de données MySQL. */
define( 'DB_USER', 'root' );

/** Mot de passe de la base de données MySQL. */
define( 'DB_PASSWORD', '' );

/** Adresse de l’hébergement MySQL. */
define( 'DB_HOST', 'localhost' );

/** Jeu de caractères à utiliser par la base de données lors de la création des tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/**
 * Type de collation de la base de données.
 * N’y touchez que si vous savez ce que vous faites.
 */
define( 'DB_COLLATE', '' );

/**#@+
 * Clés uniques d’authentification et salage.
 *
 * Remplacez les valeurs par défaut par des phrases uniques !
 * Vous pouvez générer des phrases aléatoires en utilisant
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ le service de clés secrètes de WordPress.org}.
 * Vous pouvez modifier ces phrases à n’importe quel moment, afin d’invalider tous les cookies existants.
 * Cela forcera également tous les utilisateurs à se reconnecter.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '!PQj/`ox:neDTj&vr3C{BnMF(RqOXLN:q3j%E7b9%U]yi[WfWNO1(b$sO(>_d~`|' );
define( 'SECURE_AUTH_KEY',  'VvQbwNo:zOO6-wcbDIFy/q$s)cf$T*^iFsY5nz;R+0GpW l)_3XdM?!+JmJ^/yW=' );
define( 'LOGGED_IN_KEY',    'a~dold_1_f?aC%:%CDGB,w |1a+9PgJ_j+{t&2D{f&/!L{}MK_-M1!.)W6|?p>9>' );
define( 'NONCE_KEY',        '97tfH1(13r+C(uZ.7k|I#W<+ZR0970z|o/#.$,arEX|IulhK|+XLKMT8$#(|).e#' );
define( 'AUTH_SALT',        'Y_ZHIMG_h)AFBF0J?x@PBo+dn$r={{5E;ie 74edk jOz0v j5JL!4qRdYw&]F:c' );
define( 'SECURE_AUTH_SALT', 'w!$8,G$nI_^.w,s}`M A>cg<l%.iscQUn8:n~gK1[j2{9q!t;c3Gy3aW*&/iZ!|?' );
define( 'LOGGED_IN_SALT',   'k@(Mcdrp::eIS>B1iCmVe$+_#>:Pr~k}ljYVkczCM}sa@/!}Uy$2C+lPv]q.6>~~' );
define( 'NONCE_SALT',       'u=xaeF%zLV#hpdf:gUEN 4!~g4q4%]=Tt+6-TL<IxH%`h)&c$FgeMOBF|ktm(p]Z' );
/**#@-*/

/**
 * Préfixe de base de données pour les tables de WordPress.
 *
 * Vous pouvez installer plusieurs WordPress sur une seule base de données
 * si vous leur donnez chacune un préfixe unique.
 * N’utilisez que des chiffres, des lettres non-accentuées, et des caractères soulignés !
 */
$table_prefix = 'wev_';

/**
 * Pour les développeurs : le mode déboguage de WordPress.
 *
 * En passant la valeur suivante à "true", vous activez l’affichage des
 * notifications d’erreurs pendant vos essais.
 * Il est fortement recommandé que les développeurs d’extensions et
 * de thèmes se servent de WP_DEBUG dans leur environnement de
 * développement.
 *
 * Pour plus d’information sur les autres constantes qui peuvent être utilisées
 * pour le déboguage, rendez-vous sur le Codex.
 *
 * @link https://fr.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* C’est tout, ne touchez pas à ce qui suit ! Bonne publication. */

/** Chemin absolu vers le dossier de WordPress. */
if ( ! defined( 'ABSPATH' ) )
  define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Réglage des variables de WordPress et de ses fichiers inclus. */
require_once( ABSPATH . 'wp-settings.php' );
